<?php

namespace App\Controllers;

use phpDocumentor\Reflection\Types\Null_;

class Profile extends BaseController
{
    function __construct()
    {
        $this->model = new \App\Models\User();
    }
    public function edit($id)
    {
        return json_encode($this->model->find($id));
    }
    public function index()
    {
        $session = \config\Services::session();
        if ($session->get('user') == NULL) {
            return  redirect()->to('/login');
        } else {

            $nama = [
                'title' => 'SIPEBU | Profile'
            ];

            return view('profile', $nama);
        }
    }
}
