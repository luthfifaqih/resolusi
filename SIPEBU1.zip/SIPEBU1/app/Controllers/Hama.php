<?php

namespace App\Controllers;

use phpDocumentor\Reflection\Types\Null_;

class Hama extends BaseController
{
    function __construct()
    {
        $this->model = new \App\Models\Hama();
    }
    public function hapus($id)
    {
        $this->model->delete($id);
        return  redirect()->to('/Hama');
    }
    public function edit($id)
    {
        return json_encode($this->model->find($id));
    }
    public function simpan()
    {
        $validasi = \Config\Services::validation();
        $aturan = [

            'jenis' => [
                'lable' => 'Jenis',
                'rules' => 'required|min_length[2]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 2 karakter'
                ]
            ], 'penanganan' => [
                'lable' => 'Penanganan',
                'rules' => 'required|min_length[4]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 4 karakter'
                ]
            ]
        ];
        $validasi->setRules($aturan);
        if ($validasi->withRequest($this->request)->run()) {
            $id = $this->request->getPost('id');
            $jenis = $this->request->getPost('jenis');
            $penanganan = $this->request->getPost('penanganan');

            $data = [
                'id' => $id,
                'jenis' => $jenis,
                'penanganan' => $penanganan,


            ];
            $this->model->save($data);

            $hasil['Sukses'] = "Data berhasil disimpan";
            $hasil['Error'] = true;
        } else {
            $hasil['Sukses'] = false;
            $hasil['Error'] = $validasi->listErrors();
        }


        return json_encode($hasil);
    }
    public function index()
    {
        $session = \config\Services::session();
        if ($session->get('user') == NULL) {
            return  redirect()->to('/login');
        } else {

            $jumlah = 5;
            $data['hama'] = $this->model->orderBy('id', 'desc')->paginate($jumlah);
            $data['pager'] = $this->model->pager;
            $data['nomor'] = ($this->request->getVar('page') == 1) ? '0' : $this->request->getVar('nomor');
            return view('hama/tablehama', $data);
        }
    }
}
