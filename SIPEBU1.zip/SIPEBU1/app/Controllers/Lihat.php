<?php

namespace App\Controllers;

use phpDocumentor\Reflection\Types\Null_;

class Lihat extends BaseController
{
    public function index()
    {
        return view('penyuluh/Profile');
    }
}
