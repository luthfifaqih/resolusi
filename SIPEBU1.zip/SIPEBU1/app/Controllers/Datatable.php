<?php

namespace App\Controllers;

use phpDocumentor\Reflection\Types\Null_;

class Datatable extends BaseController
{
    function __construct()
    {
        $this->model = new \App\Models\Datatable();
    }
    public function hapus($id)
    {
        $this->model->delete($id);
        return  redirect()->to('/Datatable');
    }
    public function edit($id)
    {
        return json_encode($this->model->find($id));
    }
    public function simpan()
    {
        $validasi = \Config\Services::validation();
        $aturan = [
            'nama' => [
                'lable' => 'Nama',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
            'jabatan' => [
                'lable' => 'Jabatan',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
            'wil_penyuluhan' => [
                'lable' => 'Wil_penyuluhan',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
            'kontak' => [
                'lable' => 'Kontak',
                'rules' => 'required|min_length[10]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 10 karakter'
                ]
            ]
        ];
        $validasi->setRules($aturan);
        if ($validasi->withRequest($this->request)->run()) {
            $id = $this->request->getPost('id');
            $nama = $this->request->getPost('nama');
            $jabatan = $this->request->getPost('jabatan');
            $wil_penyuluhan = $this->request->getPost('wil_penyuluhan');
            $kontak = $this->request->getPost('kontak');

            $data = [
                'id' => $id,
                'nama' => $nama,
                'jabatan' => $jabatan,
                'wil_penyuluhan' => $wil_penyuluhan,
                'kontak' => $kontak


            ];
            $this->model->save($data);

            $hasil['Sukses'] = "Data berhasil disimpan";
            $hasil['Error'] = true;
        } else {
            $hasil['Sukses'] = false;
            $hasil['Error'] = $validasi->listErrors();
        }


        return json_encode($hasil);
    }
    public function index()
    {
        $session = \config\Services::session();
        if ($session->get('user') == NULL) {
            return  redirect()->to('/login');
        } else {
            $nama = [
                'title' => 'SIPEBU | Home'
            ];

            $jumlah = 5;
            $data['penyuluh'] = $this->model->orderBy('id', 'desc')->paginate($jumlah);
            $data['pager'] = $this->model->pager;
            $data['nomor'] = ($this->request->getVar('page') == 1) ? '0' : $this->request->getVar('nomor');
            return view('penyuluh/tablepenyuluh', $data);
        }
    }
    public function lihat()
    {
        return view('penyuluh/Profile');
    }
}
