<?php

namespace App\Controllers;

class Home extends BaseController
{
    function __construct()
    {
        $this->modelhama = new \App\Models\Hama();
        $this->modelpenyuluh = new \App\Models\Datatable();
        $this->modelgapoktan = new \App\Models\Gapoktan();
        $this->modelbantuan = new \App\Models\Bantuan();
    }
    public function index()
    {
        $data = [
            'title' => 'SIPEBU | Home'
        ];

        $data['jml_hama'] = $this->modelhama->countAllResults();
        $data['jml_penyuluh'] = $this->modelpenyuluh->countAllResults();
        $data['jml_gapoktan'] = $this->modelgapoktan->countAllResults();
        $data['jml_bantuan'] = $this->modelbantuan->countAllResults();


        return view('landingpage/home', $data);
    }
}
