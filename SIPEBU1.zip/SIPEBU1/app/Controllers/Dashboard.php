<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    function __construct()
    {
        $this->modelhama = new \App\Models\Hama();
        $this->modelpenyuluh = new \App\Models\Datatable();
        $this->modelgapoktan = new \App\Models\Gapoktan();
        $this->modelbantuan = new \App\Models\Bantuan();
    }
    public function index()
    {

        $session = \config\Services::session();
        if ($session->get('user') == NULL) {
            return  redirect()->to('/login');
        } else {
            $data = [
                'title' => 'SIPEBU | Dashboard'
            ];

            $data['jml_hama'] = $this->modelhama->countAllResults();
            $data['jml_penyuluh'] = $this->modelpenyuluh->countAllResults();
            $data['jml_gapoktan'] = $this->modelgapoktan->countAllResults();
            $data['jml_bantuan'] = $this->modelbantuan->countAllResults();

            return view('dashboard/index', $data);
        }
    }
}
