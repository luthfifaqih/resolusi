<?= $this->extend('dsblayout/template'); ?>

<?= $this->section('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="Dashboard">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">

            <!-- Left side columns -->
            <div class="col-lg-8">
                <div class="row">

                    <!-- Gapoktan Card -->
                    <div class="col-xxl-4 col-md-6">

                        <div class="card info-card customers-card">

                            <div class="card-body">
                                <h5 class="card-title">Gapoktan</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><span data-purecounter-start="0" data-purecounter-end="<?= $jml_gapoktan ?>" data-purecounter-duration="1" class="purecounter"></span></h6>
                                        <span class="text-muted small pt-2 ps-1">Kelompok</span>

                                    </div>
                                </div>

                            </div>
                        </div>

                    </div><!-- End Sales Card -->

                    <!-- Penyuluh Card -->
                    <div class="col-xxl-4 col-md-6">
                        <div class="card info-card revenue-card">
                            <div class="card-body">
                                <h5 class="card-title">Penyuluh</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-emoji-smile"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><span data-purecounter-start="0" data-purecounter-end="<?= $jml_penyuluh ?>" data-purecounter-duration="1" class="purecounter"></span></h6>
                                        <span class="text-muted small pt-2 ps-1">Orang</span>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Revenue Card -->

                    <!-- Hama Card -->
                    <div class="col-xxl-4 col-md-6">

                        <div class="card info-card customers-card">

                            <div class="card-body">
                                <h5 class="card-title">Hama</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-bug"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><span data-purecounter-start="0" data-purecounter-end="<?= $jml_hama ?>" data-purecounter-duration="1" class="purecounter"></span></h6>
                                        <span class="text-muted small pt-2 ps-1">Jenis</span>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div><!-- End Hama Card -->
                    <!-- Hama Card -->
                    <div class="col-xxl-4 col-md-6">

                        <div class="card info-card customers-card">

                            <div class="card-body">
                                <h5 class="card-title">Bantuan</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-gift"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><span data-purecounter-start="0" data-purecounter-end="<?= $jml_bantuan ?>" data-purecounter-duration="1" class="purecounter"></span></h6>
                                        <span class="text-muted small pt-2 ps-1"></span>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div><!-- End Bantuan Card -->
                </div>
            </div><!-- End Left side columns -->

            <!-- Right side columns -->
            <div class="col-lg-8">
                <div class="row">



                    <!-- Grafik Data -->
                    <div class="card">

                        <div class="card-body pb-0">
                            <h5 class="card-title">Grafik Data</h5>

                            <div id="trafficChart" style="min-height: 400px;" class="echart"></div>

                            <script>
                                document.addEventListener("DOMContentLoaded", () => {
                                    echarts.init(document.querySelector("#trafficChart")).setOption({
                                        tooltip: {
                                            trigger: 'item'
                                        },
                                        legend: {
                                            top: '5%',
                                            left: 'center'
                                        },
                                        series: [{
                                            name: 'Access From',
                                            type: 'pie',
                                            radius: ['40%', '70%'],
                                            avoidLabelOverlap: false,
                                            label: {
                                                show: false,
                                                position: 'center'
                                            },
                                            emphasis: {
                                                label: {
                                                    show: true,
                                                    fontSize: '18',
                                                    fontWeight: 'bold'
                                                }
                                            },
                                            labelLine: {
                                                show: false
                                            },
                                            data: [{
                                                    value: 1048,
                                                    name: 'Penyuluh'
                                                },
                                                {
                                                    value: 735,
                                                    name: 'Gapoktan'
                                                },
                                                {
                                                    value: 580,
                                                    name: 'Hama'
                                                }
                                            ]
                                        }]
                                    });
                                });
                            </script>

                        </div>
                    </div><!-- End Website Traffic -->

                </div><!-- End Right side columns -->

            </div>
    </section>

</main><!-- End #main -->

<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>SIPEBU</span></strong>. All Rights Reserved
    </div>
</footer><!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<?= $this->endSection(); ?>