<!-- ======= Header ======= -->
<header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

        <a href="#hero" class="logo d-flex align-items-center">
            <img src="assets/img/logo.png" alt="">
            <span>SIPEBU</span>
        </a>

        <nav id="navbar" class="navbar">
            <ul>

                <li><a class="nav-link scrollto" href="#portfolio">Galeri</a></li>
                <li><a class="nav-link scrollto" href="#team">Team Development</a></li>
                <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
                <li class="dropdown"><a href="#"><span>Informasi</span> <i class="bi bi-chevron-down"></i></a>
                    <ul>
                        <li><a href="#">Penyuluh</a></li>
                        <li><a href="#">Gapoktan</a></li>
                        <li><a href="#">Lahan Baku</a></li>
                        <li class="dropdown"><a href="#"><span>Informasi Harga Pupuk</span> <i class="bi bi-chevron-right"></i></a>
                            <ul>
                                <li><a href="#">Subsidi</a></li>
                                <li><a href="#">Non Subsidi</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Bantuan</a></li>
                    </ul>
                </li>
                <li><a class="getstarted scrollto" href="Login">Login</a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

    </div>
</header><!-- End Header -->