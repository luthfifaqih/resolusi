<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link collapsed" href="Dashboard">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->
        <li class="nav-heading">Data Penyuluh dan Gapoktan</li>

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-menu-button-wide"></i><span>Profile</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="Profile">
                        <i class="bi bi-circle"></i><span>Profile Pengguna</span>
                    </a>
                </li>

            </ul>
        </li><!-- End Components Nav -->
        <li class="nav-heading">Table Data</li>

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-layout-text-window-reverse"></i><span>Tabel</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="Datatable">
                        <i class="bi bi-circle"></i><span>Penyuluh</span>
                    </a>
                </li>
                <li>
                    <a href="Gapoktan">
                        <i class="bi bi-circle"></i><span>Gapoktan</span>
                    </a>
                </li>
                <li>
                    <a href="Lahan">
                        <i class="bi bi-circle"></i><span>Luas Lahan</span>
                    </a>
                </li>
                <li>
                    <a href="Hama">
                        <i class="bi bi-circle"></i><span>Hama</span>
                    </a>
                </li>


            </ul>
        </li><!-- End Tables Nav -->
        <li class="nav-heading">Jenis dan Harga Pupuk</li>

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-tree"></i><span>Pupuk</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="Pupuksub">
                        <i class="bi bi-circle"></i><span>Pupuk</span>
                    </a>
                </li>

            </ul>
        </li>
        <li class="nav-heading">Data Bantuan </li>


        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-gift"></i><span>Bantuan</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="Bantuan">
                        <i class="bi bi-circle"></i><span>Bantuan</span>
                    </a>
                </li>

            </ul>
        </li><!-- End Forms Nav -->

        <li class="nav-heading">Keluar</li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="Login/Logout">
                <i class="bi bi-box-arrow-in-left"></i>
                <span>Logout</span>
            </a>
        </li><!-- End Login Page Nav -->

    </ul>

</aside><!-- End Sidebar-->