<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>SIPEBU | Hama</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/logo.png" rel="icon">
    <link href="assets/img/logo.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->

    <link href="assets2/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets2/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets2/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets2/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets2/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets2/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets2/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets2/css/style.css" rel="stylesheet">

</head>

<body>

    <?= $this->include('dsblayout/navbar'); ?>

    <?= $this->include('dsblayout/sidebar'); ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Data Tables</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="Dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active">Hama</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"></h5>
                <!-- Disabled Backdrop Modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#verticalycentered">
                    <i class="bi bi-journal-plus">Tambah</i>
                </button>
                <div class="modal fade" id="verticalycentered" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">

                            <div class="alert alert-danger alert-dismissible fade show Error " role="alert" style="display: none;"></div>
                            <div class="alert alert-success alert-dismissible fade show Sukses" role="alert" style="display: none;"></div>

                            <div class="modal-header">

                                <h5 class="card-title">Hama</h5>

                                <button type="button" class="btn-close tombol-tutup" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <!-- Vertical Form -->
                                <input type="hidden" id="inputid">
                                <form class="row g-3">

                                    <div class="col-12">
                                        <label for="inputjenis" class="form-label">Jenis Hama</label>
                                        <select id="inputjenis" class="form-select">
                                            <option selected>pilih</option>
                                            <option>Tikus</option>
                                            <option>Wereng</option>
                                            <option>Keong Mas</option>
                                            <option>Kepik Hijau</option>
                                            <option>Walang Sangit</option>
                                            <option>Burung</option>
                                            <option>Penggerek Batang Padi</option>

                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label for="inputpenanganan" class="form-label">Penanganan Hama</label>
                                        <div class="row mb-3">
                                            <div class="col-sm-12">
                                                <textarea id="inputpenanganan" class="form-control" style="height: 100px"></textarea>
                                            </div>

                                </form>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary tombol-tutup" data-bs-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary" id="Simpan">Simpan</button>
                            </div>
                        </div>
                    </div>
                </div><!-- End Disabled Backdrop Modal-->

            </div>
        </div>
        <section class="section">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Table Hama</h5>

                            <!-- Table with stripped rows -->
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Jenis Hama</th>
                                        <th scope="col">Penanganan Hama</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    foreach ($hama as $k => $v) {
                                        $nomor = $nomor + 1;
                                    ?>
                                        <tr>
                                            <th scope="row"><?php echo $nomor ?></th>
                                            <td><?php echo $v['jenis'] ?></td>
                                            <td><?php echo $v['penanganan'] ?></td>

                                            <td>
                                                <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#verticalycentered" onclick="edit(<?php echo $v['id'] ?>)">
                                                    <i class="bi bi-pencil"></i>
                                                </button>

                                                <button type="button" class="btn btn-danger btn-sm" onclick="hapus(<?php echo $v['id'] ?>)">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php }
                                    ?>



                                </tbody>
                            </table>
                            <?php
                            $linkPagination = $pager->links();
                            $linkPagination = str_replace('<li class="active">', '<li class="page-item active">', $linkPagination);
                            $linkPagination = str_replace('<li>', '<li class="page-item">', $linkPagination);
                            $linkPagination = str_replace("<a", "<a class='page-link'", $linkPagination);
                            echo $linkPagination;
                            ?>


                        </div>
                    </div>

                </div>
            </div>
        </section>

    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>SIPEBU</span></strong>. All Rights Reserved
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="assets2/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="assets2/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets2/vendor/chart.js/chart.min.js"></script>
    <script src="assets2/vendor/echarts/echarts.min.js"></script>
    <script src="assets2/vendor/quill/quill.min.js"></script>
    <script src="assets2/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="assets2/vendor/tinymce/tinymce.min.js"></script>
    <script src="assets2/vendor/php-email-form/validate.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <!-- Template Main JS File -->
    <script src="assets2/js/main.js"></script>
    <script>
        function hapus($id) {
            var result = confirm('Lanjut Menghapus ?');
            if (result) {
                window.location = "<?php echo site_url("Hama/hapus") ?>/" + $id;
            }

        }

        function edit($id) {
            $.ajax({
                url: "<?php echo site_url("Hama/edit") ?>/" + $id,
                type: "GET",
                success: function(hasil) {
                    var $obj = $.parseJSON(hasil);
                    if ($obj.id != '') {
                        $('#inputid').val($obj.id);
                        $('#inputjenis').val($obj.jenis);
                        $('#inputpenanganan').val($obj.penanganan);

                    }
                }
            });
        }

        function bersih() {
            $('#inputjenis').val('');
            $('#inputpenanganan').val('');

        }
        $('.tombol-tutup').on('click', function() {
            if ($('.sukses').is(":visible")) {
                window.location.href = "<?php echo current_url() . "?" . $_SERVER['QUERY_STRING'] ?>";
            }
            $('.alert').hide();
            bersih();
        })

        $('#Simpan').on('click', function() {
            var $id = $('#inputid').val();
            var $jenis = $('#inputjenis').val();
            var $penanganan = $('#inputpenanganan').val();


            $.ajax({
                url: "<?php echo site_url("Hama/simpan") ?>",
                type: "POST",
                data: {
                    id: $id,
                    jenis: $jenis,
                    penanganan: $penanganan,


                },
                success: function(hasil) {
                    var $obj = $.parseJSON(hasil);
                    if ($obj.Sukses == false) {
                        $('.Sukses').hide();
                        $('.Error').show();
                        $('.Error').html($obj.Error);
                    } else {
                        $('#verticalycentered').hide();
                        $('.Error').hide();
                        $('.Sukses').show();
                        $('.Sukses').html($obj.Sukses);
                        window.location = '<?= site_url('Hama') ?>';
                    }
                }

            });
            //bersih();
        });
    </script>


</body>

</html>