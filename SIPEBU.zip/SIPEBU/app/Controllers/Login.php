<?php

namespace App\Controllers;

class Login extends BaseController
{
    public function index()
    {
        return view('login');
    }
    public function prosesLogin()
    {
        $name = $this->request->getGetPost('name');
        $password = $this->request->getGetPost('password');


        $user_model = new \App\Models\User();

        $user = $user_model->getUserLogin($name, $password);

        $session = \config\Services::session();
        if ($user) {

            $session->set(['user' => $user]);

            return redirect()->to('/dashboard');
        } else {

            $session->setFlashdata(['error_mesage' => 'Username dan password tidak sesuai']);
            return redirect()->to('/login');
        }
    }

    public function Logout()
    {
        $session = \config\Services::session();

        $session->destroy();
        return redirect()->to('/');
    }
}
