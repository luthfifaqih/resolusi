<?php

namespace App\Controllers;

use phpDocumentor\Reflection\Types\Null_;

class Gapoktan extends BaseController
{
    function __construct()
    {
        $this->model = new \App\Models\Gapoktan();
    }
    public function edit($id)
    {
        return json_encode($this->modal->find($id));
    }
    public function simpan()
    {
        $validasi = \Config\Services::validation();
        $aturan = [
            'nama' => [
                'lable' => 'Nama',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
            'ttl' => [
                'lable' => 'Ttl',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
            'alamat' => [
                'lable' => 'Alamat',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
            'jenis_kelamin' => [
                'lable' => 'Jenis_kelamin',
                'rules' => 'required|min_length[1]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 12 karakter'
                ]
            ],   'jenjang_usia' => [
                'lable' => 'Jenjang_usia',
                'rules' => 'required|min_length[2]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
            'nama_gapoktan' => [
                'lable' => 'Nama_gapoktan',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ],
            'desa' => [
                'lable' => 'Desa',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 12 karakter'
                ]
            ],
            'jabatan' => [
                'lable' => 'Jabatan',
                'rules' => 'required|min_length[5]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'min_length' => 'Minimum karakter untuk field {field} adalah 5 karakter'
                ]
            ]
        ];
        $validasi->setRules($aturan);
        if ($validasi->withRequest($this->request)->run()) {
            $id = $this->request->getPost('id');
            $nama = $this->request->getPost('nama');
            $ttl = $this->request->getPost('ttl');
            $alamat = $this->request->getPost('alamat');
            $jenis_kelamin = $this->request->getPost('jenis_kelamin');
            $jenjang_usia = $this->request->getPost('jenjang_usia');
            $nama_gapoktan = $this->request->getPost('nama_gapoktan');
            $desa = $this->request->getPost('desa');
            $jabatan = $this->request->getPost('jabatan');

            $data = [
                'id' => $id,
                'nama' => $nama,
                'ttl' => $ttl,
                'alamat' => $alamat,
                'jenis_kelamin' => $jenis_kelamin,
                'jenjang_usia' => $jenjang_usia,
                'nama_gapoktan' => $nama_gapoktan,
                'desa' => $desa,
                'jabatan' => $jabatan


            ];
            $this->model->save($data);

            $hasil['Sukses'] = "Data berhasil disimpan";
            $hasil['Error'] = true;
        } else {
            $hasil['Sukses'] = false;
            $hasil['Error'] = $validasi->listErrors();
        }


        return json_encode($hasil);
    }
    public function index()
    {
        $session = \config\Services::session();
        if ($session->get('user') == NULL) {
            return  redirect()->to('/login');
        } else {
            $nama = [
                'title' => 'SIPEBU | Home'
            ];
            $jumlah = 5;
            $data['penyuluh'] = $this->model->orderBy('id', 'desc')->paginate($jumlah);
            $data['pager'] = $this->model->pager;
            $data['nomor'] = ($this->request->getVar('page') == 1) ? '0' : $this->request->getVar('page');
            return view('gapoktan\tablegapoktan', $data, $nama);
        }
    }
}
