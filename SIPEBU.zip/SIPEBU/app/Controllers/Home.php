<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $nama = [
            'title' => 'SIPEBU | Home'
        ];

        return view('landingpage/home', $nama);
    }
    public function dashboard()
    {
        return view('dashboard');
    }
}
