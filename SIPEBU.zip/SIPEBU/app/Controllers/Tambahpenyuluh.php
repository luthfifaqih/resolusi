<?php

namespace App\Controllers;

class Tambahpenyuluh extends BaseController
{
    function __construct()
    {
        $this->Model = new \App\Models\Datatable();
    }
    public function index()
    {
        $session = \config\Services::session();
        if ($session->get('user') == NULL) {
            return  redirect()->to('/login');
        } else {
            return view('penyuluh\tambah');
        }
    }
}
