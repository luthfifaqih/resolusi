<?php

namespace App\Controllers;

use phpDocumentor\Reflection\Types\Null_;

class Dashboard extends BaseController
{
    public function index()
    {

        $session = \config\Services::session();
        if ($session->get('user') == NULL) {
            return  redirect()->to('/login');
        } else {

            $nama = [
                'title' => 'SIPEBU | Dashboard'
            ];

            return view('dashboard/index', $nama);
        }
    }
}
