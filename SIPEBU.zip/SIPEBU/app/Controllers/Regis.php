<?php

namespace App\Controllers;

class Regis extends BaseController
{
    public function index()
    {
        return view('regis');
    }
}
